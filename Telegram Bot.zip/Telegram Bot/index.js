const express = require("express");
var bodyParser = require("body-parser");
const {handler} = require("./controller/lib");
const dotenv = require('dotenv');
const morgan = require('morgan');
const connectDB = require('./0 db connection.js');
const completeURL = require('./get url.js')
const { sendMessage } = require('./controller/lib/Telegram.js');
const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));



// load env vars
dotenv.config({ path: './config.env'});
connectDB(); 

// //   route file
let better = require('./controller/lib/3 db api.js')
let createbetter = require('./controller/lib/3 db api.js')
let Betterlogic = require('./1 db schema.js')

// // Mount routers
app.use(completeURL);
app.use('/better' ,better);
app.use('/createbetter' ,createbetter);


if(process.env.NODE_ENV === 'development'){
  app.use(morgan('dev'))
}




// registration
async function registerUser(chatId, userId) {
    const existingUser = await Betterlogic.findOne({ id: chatId });
    if(existingUser){
      const messageObj = { chat: { id: chatId } };
      await sendMessage(messageObj, 'You are already registered!');
    }
}

// checkregistration
async function checkregistration(chatId, userId) {
  const existingUser = await Betterlogic.findOne({ id: chatId });
  if(!existingUser){
    const messageObj = { chat: { id: chatId } };
    await sendMessage(messageObj, 'please register you phone  Using /register!');
  }
}


app.post("/*", async function (req, res) {
      const message = req.body.message;
    const chatId = message.from.id;
    const userId = message.from.first_name;
    const messageText = message.text;
try {
  if (messageText.startsWith('/register')) {
    await registerUser(chatId, userId);
}
if (messageText.startsWith('/price')) {
  await checkregistration(chatId, userId);
}
res.send(await handler(req));
// res.send({success:"true"});
} catch (error) {
  console.log(error);
 res.send({success:false,error:"Pending"}) 
} 
});



app.listen(8002, function () {
  console.log("Server started at 8002...");
});
