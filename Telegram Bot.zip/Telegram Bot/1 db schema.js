const mongoose = require('mongoose');

const TelegrambotSchema = new mongoose.Schema
({
    name:
    {
        type: String,
        require:[true, 'Please add  a name'],
        unique: true,
        trim: true,
        maxlength: [50,'Name can not be more than 50 characters']
    },
    id:
    {
        type: Number,
        require:[true, 'Please add  a id'],
        unique: true,
        trim: true,
        maxlength: [50,'Name can not be more than 50 characters']
    },          
});


module.exports = mongoose.model('better Schema',TelegrambotSchema) 